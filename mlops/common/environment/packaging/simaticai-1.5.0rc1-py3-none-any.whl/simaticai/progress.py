# Copyright (C) Siemens AG 2021. All Rights Reserved. Confidential.

"""
Progress indicator.

If the amount is known beforehand, it displays the progress in percentage, otherwise it displays a rotating progress indicator.
"""

import sys
import threading


class ProgressCallback:
    """
    A class that is callable from another method that wants to display a progress indicator.

    Args:
        label (str):         This text will be printed before the current progress.
        total (float):       The total amount that corresponds to 100%.
        incrementing (bool): If True, the amount will be added to the current value, otherwise the amount will replace the current value.
    """

    def __init__(self, label, total, incrementing=False):
        """
        Initialize a ProgressCallback object.

        Args:
            label (str):         This text will be printed before the current progress.
            total (float):       The total amount that corresponds to 100%.
            incrementing (bool): If True, the amount will be added to the current value, otherwise the amount will replace the current value.
        """

        self._lock = threading.Lock()
        self.label = label
        self.incrementing = incrementing
        try:
            self.total = float(total)
        except Exception:
            self.total = 0
        self.current = 0
        self.phases = ["↑", "↗", "→", "↘", "↓", "↙", "←", "↖"]
        self.phase = 0

    def __call__(self, amount):
        """
        Callback method that prints the current progress.
        When called, depending on the `incrementing` flag, the current amount will be incremented or replaced by the given amount.
        Args:
            amount (float): A number between zero and the total amount.
        """
        with self._lock:
            if self.incrementing:
                self.current += amount
            else:
                self.current = amount

            if 0 < self.total:
                self.print_progress()
            else:
                self.print_spinner()
                self.phase = (self.phase + 1) % 8

    def print_progress(self):
        """
        Prints a formatted string with the current progress.
        Moves the cursor to the beginning of the line for overwriting the previous progress.
        """
        print('%s: %.2f%% [%d / %d]' % (self.label, self.current / self.total * 100, self.current, self.total), file=sys.stdout, end='\r')

    def print_spinner(self):
        """
        Prints a formatted string with a rotating progress indicator.
        Moves the cursor to the beginning of the line for overwriting the previous progress.
        """
        print('%s: %s Total: %d' % (self.label, self.phases[self.phase], self.current), file=sys.stdout, end='\r')
